import"../../../chunks/user-013b6325.js";import{l as m,s as p}from"../../../chunks/_layout-367c0ea2.js";import"../../../chunks/paths-b4419565.js";export{m as load,p as ssr};
