import"../../../chunks/user-a20f9e61.js";import{l as m,s as p}from"../../../chunks/_layout-e41790bc.js";import"../../../chunks/paths-b4419565.js";export{m as load,p as ssr};
