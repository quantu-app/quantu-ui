import"../../../chunks/user-c384e0b4.js";import{l as m,s as p}from"../../../chunks/_layout-cc4b1469.js";import"../../../chunks/paths-b4419565.js";export{m as load,p as ssr};
