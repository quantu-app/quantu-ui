import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-1b3a9cc2.js";export{t as component};
