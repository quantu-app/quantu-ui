import{_ as r}from"./_layout-a985426c.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-488abf67.js";export{t as component,r as universal};
