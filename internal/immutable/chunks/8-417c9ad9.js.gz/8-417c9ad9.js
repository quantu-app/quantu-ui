import{default as t}from"../components/pages/(authed)/quizzes/_local_learnable_resource_/questions/create/_page.svelte-1737cbf1.js";export{t as component};
