import{default as t}from"../components/pages/_layout.svelte-2ff065f1.js";export{t as component};
