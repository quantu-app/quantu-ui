import{default as t}from"../components/error.svelte-7f80073f.js";export{t as component};
