import{default as t}from"../entry/(unauthed)-login-page.svelte.8022a72c.js";export{t as component};
