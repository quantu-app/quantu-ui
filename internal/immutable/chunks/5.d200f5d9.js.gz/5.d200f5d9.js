import{default as t}from"../entry/(authed)-page.svelte.4718b04e.js";export{t as component};
