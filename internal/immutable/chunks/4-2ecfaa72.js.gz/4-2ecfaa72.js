import{default as t}from"../components/pages/(authed)/_page.svelte-a579858f.js";export{t as component};
