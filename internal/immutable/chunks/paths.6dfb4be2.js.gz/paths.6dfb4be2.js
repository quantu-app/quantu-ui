var s;const t=((s=globalThis.__sveltekit_1nr6yyh)==null?void 0:s.base)??"/quantu-ui";var a;const e=((a=globalThis.__sveltekit_1nr6yyh)==null?void 0:a.assets)??t;export{e as a,t as b};
