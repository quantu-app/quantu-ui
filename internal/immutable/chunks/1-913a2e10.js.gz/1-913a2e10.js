import{default as t}from"../components/error.svelte-27539858.js";export{t as component};
