import{default as t}from"../entry/error.svelte.68d5c790.js";export{t as component};
