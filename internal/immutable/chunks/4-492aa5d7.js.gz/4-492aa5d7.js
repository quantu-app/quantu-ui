import{default as t}from"../components/pages/(authed)/_page.svelte-d6f32810.js";export{t as component};
