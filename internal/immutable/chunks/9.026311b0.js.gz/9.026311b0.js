import{default as t}from"../entry/(unauthed)-login-page.svelte.062a566a.js";export{t as component};
