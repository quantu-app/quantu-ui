import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-3ef49d4f.js";export{t as component};
