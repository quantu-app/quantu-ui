import{default as t}from"../components/pages/(authed)/_local_quiz_id_/_page.svelte-66d2bd38.js";export{t as component};
