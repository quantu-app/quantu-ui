import{default as t}from"../components/pages/(authed)/_local_quiz_id_/_page.svelte-45705439.js";export{t as component};
