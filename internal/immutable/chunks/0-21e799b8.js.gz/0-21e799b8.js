import{_ as r}from"./_layout-da46b06b.js";import{default as t}from"../components/pages/_layout.svelte-d6b62f37.js";export{t as component,r as universal};
