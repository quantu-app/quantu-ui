import{default as t}from"../entry/(authed)-quizzes-_local_learnable_resource_-questions-create-page.svelte.e06a3cdb.js";export{t as component};
