import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-a44b6ca5.js";export{t as component};
