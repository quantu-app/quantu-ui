import{default as t}from"../components/error.svelte-23cf65fc.js";export{t as component};
