import{default as t}from"../components/pages/(authed)/_page.svelte-d3500818.js";export{t as component};
