import{_ as r}from"./_layout-65075329.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-ffa9efe8.js";export{t as component,r as universal};
