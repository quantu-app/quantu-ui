import{default as t}from"../components/pages/(authed)/_page.svelte-4563b381.js";export{t as component};
