import{default as t}from"../components/error.svelte-6eb64fc4.js";export{t as component};
