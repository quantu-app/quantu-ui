import{default as t}from"../entry/error.svelte.1f7c9c0a.js";export{t as component};
