import{default as t}from"../components/pages/(authed)/_page.svelte-69a168bf.js";export{t as component};
