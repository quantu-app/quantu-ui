import{_ as r}from"./_layout-e41790bc.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-2d86313c.js";export{t as component,r as universal};
