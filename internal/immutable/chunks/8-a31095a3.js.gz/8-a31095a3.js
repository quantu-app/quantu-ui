import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-a2b6a449.js";export{t as component};
