import{default as t}from"../components/pages/(authed)/_page.svelte-609dc08e.js";export{t as component};
