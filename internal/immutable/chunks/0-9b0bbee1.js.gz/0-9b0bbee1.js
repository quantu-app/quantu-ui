import{default as t}from"../components/pages/_layout.svelte-b2899c6a.js";export{t as component};
