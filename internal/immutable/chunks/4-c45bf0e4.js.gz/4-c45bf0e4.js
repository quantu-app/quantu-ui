import{default as t}from"../components/pages/(authed)/_page.svelte-fcd5b094.js";export{t as component};
