import{_ as r}from"./_layout-367c0ea2.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-d3f5c6ad.js";export{t as component,r as universal};
