import{_ as r}from"./_layout-e63b0da6.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-ffa9efe8.js";export{t as component,r as universal};
