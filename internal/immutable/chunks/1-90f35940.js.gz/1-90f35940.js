import{default as t}from"../components/error.svelte-6cb2e43a.js";export{t as component};
