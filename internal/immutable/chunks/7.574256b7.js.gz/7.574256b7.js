import{default as t}from"../entry/(authed)-quizzes-_local_learnable_resource_-questions-_local_question_id_-page.svelte.dce39ddf.js";export{t as component};
