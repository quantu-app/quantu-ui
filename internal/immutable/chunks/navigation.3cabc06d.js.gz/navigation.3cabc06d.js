import{h as a}from"./singletons.717191bd.js";a.disable_scroll_handling;const o=a.goto;a.invalidate;a.invalidateAll;a.preload_data;a.preload_code;a.before_navigate;a.after_navigate;export{o as g};
