import{default as t}from"../components/error.svelte-e6b96ba9.js";export{t as component};
