import{default as t}from"../components/pages/(authed)/_page.svelte-1941f647.js";export{t as component};
