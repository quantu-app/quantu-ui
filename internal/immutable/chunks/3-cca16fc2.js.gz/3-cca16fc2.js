import{_ as r}from"./_layout-4039aba4.js";import{default as t}from"../components/layout.svelte-9363d62b.js";export{t as component,r as universal};
