import{default as t}from"../entry/(unauthed)-login-page.svelte.3fee2b0b.js";export{t as component};
