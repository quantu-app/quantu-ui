import{default as t}from"../components/pages/(authed)/_page.svelte-8d4bbe85.js";export{t as component};
