import{default as t}from"../components/pages/_layout.svelte-948749de.js";export{t as component};
