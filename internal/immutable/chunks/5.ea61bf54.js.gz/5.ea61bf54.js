import{default as t}from"../entry/(authed)-page.svelte.4e3d5167.js";export{t as component};
