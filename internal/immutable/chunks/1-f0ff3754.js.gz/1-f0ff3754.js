import{default as t}from"../components/error.svelte-7b85b468.js";export{t as component};
