import{default as t}from"../entry/error.svelte.9f09f7a9.js";export{t as component};
