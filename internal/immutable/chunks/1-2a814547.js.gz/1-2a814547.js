import{default as t}from"../components/error.svelte-62f1a47c.js";export{t as component};
