import{default as t}from"../components/pages/(unauthed)/_layout.svelte-ffa9efe8.js";export{t as component};
