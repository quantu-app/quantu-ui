import{default as t}from"../components/pages/(authed)/_page.svelte-b1d2d205.js";export{t as component};
