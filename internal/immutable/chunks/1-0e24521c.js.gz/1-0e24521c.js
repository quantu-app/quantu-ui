import{default as t}from"../components/error.svelte-900bae0c.js";export{t as component};
