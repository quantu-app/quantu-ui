import{default as t}from"../entry/(authed)-quizzes-_local_learnable_resource_-questions-_local_question_id_-page.svelte.051c641a.js";export{t as component};
