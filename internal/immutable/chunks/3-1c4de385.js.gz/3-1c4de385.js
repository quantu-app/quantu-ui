import{_ as r}from"./_layout-4039aba4.js";import{default as t}from"../components/layout.svelte-b7187f6a.js";export{t as component,r as universal};
