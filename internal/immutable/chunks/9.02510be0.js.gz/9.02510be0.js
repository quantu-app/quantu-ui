import{default as t}from"../entry/(unauthed)-login-page.svelte.8ae05751.js";export{t as component};
