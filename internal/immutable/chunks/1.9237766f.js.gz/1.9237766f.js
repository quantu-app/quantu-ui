import{default as t}from"../entry/error.svelte.c1704f1b.js";export{t as component};
