import{_ as r}from"./_layout-1fad96b5.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-aa7f921e.js";export{t as component,r as universal};
