import{default as t}from"../components/pages/(unauthed)/_layout.svelte-488abf67.js";export{t as component};
