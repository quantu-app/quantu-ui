import{default as t}from"../components/pages/(authed)/_page.svelte-276e734c.js";export{t as component};
