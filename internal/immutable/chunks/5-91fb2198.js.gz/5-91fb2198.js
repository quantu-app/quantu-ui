import{default as t}from"../components/pages/(authed)/_page.svelte-6deaa916.js";export{t as component};
