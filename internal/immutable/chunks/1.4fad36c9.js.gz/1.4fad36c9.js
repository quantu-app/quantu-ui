import{default as t}from"../entry/error.svelte.42619ef5.js";export{t as component};
