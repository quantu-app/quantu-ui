import{default as t}from"../components/pages/(authed)/_page.svelte-d2b79d96.js";export{t as component};
