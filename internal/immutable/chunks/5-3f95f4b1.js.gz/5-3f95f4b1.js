import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-8a564e1d.js";export{t as component};
