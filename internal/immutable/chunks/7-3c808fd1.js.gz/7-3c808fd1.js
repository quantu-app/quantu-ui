import{default as t}from"../components/pages/(authed)/quizzes/_local_quiz_id_/questions/_local_question_id_/_page.svelte-9d9e2075.js";export{t as component};
