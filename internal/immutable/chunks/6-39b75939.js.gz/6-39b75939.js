import{default as t}from"../components/pages/(authed)/quizzes/_local_quiz_id_/_page.svelte-0921d15e.js";export{t as component};
