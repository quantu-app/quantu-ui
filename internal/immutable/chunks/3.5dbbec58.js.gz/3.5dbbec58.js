import{_ as r}from"./_layout.4039aba4.js";import{default as t}from"../entry/layout.svelte.317d9686.js";export{t as component,r as universal};
