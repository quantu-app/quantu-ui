import{default as t}from"../entry/(authed)-page.svelte.6124a651.js";export{t as component};
