import{_ as r}from"./_layout-889bb561.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-e9293951.js";export{t as component,r as universal};
