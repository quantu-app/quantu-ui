import{default as t}from"../components/pages/(unauthed)/_layout.svelte-e9293951.js";export{t as component};
