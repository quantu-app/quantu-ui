import{default as t}from"../components/error.svelte-39b594b8.js";export{t as component};
