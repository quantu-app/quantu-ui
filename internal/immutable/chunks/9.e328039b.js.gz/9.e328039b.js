import{default as t}from"../entry/(unauthed)-login-page.svelte.51420e55.js";export{t as component};
