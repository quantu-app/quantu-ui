import{default as t}from"../components/pages/(unauthed)/_layout.svelte-270ded90.js";export{t as component};
