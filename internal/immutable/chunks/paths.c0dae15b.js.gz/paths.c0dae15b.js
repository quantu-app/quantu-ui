var s;const t=((s=globalThis.__sveltekit_17kb36h)==null?void 0:s.base)??"/quantu-ui";var a;const e=((a=globalThis.__sveltekit_17kb36h)==null?void 0:a.assets)??t;export{e as a,t as b};
