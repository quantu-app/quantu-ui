import{_ as r}from"./_layout-8f5f5e65.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-5649af23.js";export{t as component,r as universal};
