import{default as t}from"../components/error.svelte-51efe04e.js";export{t as component};
