import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-d760c749.js";export{t as component};
