import{default as t}from"../entry/error.svelte.baccc937.js";export{t as component};
