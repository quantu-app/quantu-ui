import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-713d3359.js";export{t as component};
