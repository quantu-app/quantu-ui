import{default as t}from"../entry/(authed)-quizzes-_local_learnable_resource_-page.svelte.26ac699d.js";export{t as component};
