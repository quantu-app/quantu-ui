import{default as t}from"../components/pages/(authed)/_page.svelte-ac63700d.js";export{t as component};
