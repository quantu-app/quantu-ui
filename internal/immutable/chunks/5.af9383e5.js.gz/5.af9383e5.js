import{default as t}from"../entry/(authed)-page.svelte.5d44fefd.js";export{t as component};
