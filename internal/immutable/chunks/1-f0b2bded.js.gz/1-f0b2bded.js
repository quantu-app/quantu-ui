import{default as t}from"../components/error.svelte-22a9debd.js";export{t as component};
