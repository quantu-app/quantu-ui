import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-c449127e.js";export{t as component};
