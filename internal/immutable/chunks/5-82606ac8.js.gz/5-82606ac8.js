import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-0bf9ccb9.js";export{t as component};
