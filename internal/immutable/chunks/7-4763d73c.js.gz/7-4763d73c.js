import{default as t}from"../components/pages/(authed)/quizzes/_local_learnable_resource_/questions/_local_question_id_/_page.svelte-55b56745.js";export{t as component};
