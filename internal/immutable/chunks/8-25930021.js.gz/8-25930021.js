import{default as t}from"../components/pages/(authed)/quizzes/_local_quiz_id_/questions/create/_page.svelte-a09f6602.js";export{t as component};
