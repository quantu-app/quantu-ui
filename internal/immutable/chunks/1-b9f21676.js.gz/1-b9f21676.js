import{default as t}from"../components/error.svelte-fbade7a9.js";export{t as component};
