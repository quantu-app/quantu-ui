import{default as t}from"../components/pages/(authed)/_page.svelte-240ef42f.js";export{t as component};
