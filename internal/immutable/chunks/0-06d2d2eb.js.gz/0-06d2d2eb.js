import{default as t}from"../components/pages/_layout.svelte-9f57a985.js";export{t as component};
