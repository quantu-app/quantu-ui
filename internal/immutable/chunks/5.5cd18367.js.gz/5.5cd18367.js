import{default as t}from"../entry/(authed)-page.svelte.d07ad5af.js";export{t as component};
