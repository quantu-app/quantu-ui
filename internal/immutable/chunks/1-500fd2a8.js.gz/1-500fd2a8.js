import{default as t}from"../components/error.svelte-e8d5a6e2.js";export{t as component};
