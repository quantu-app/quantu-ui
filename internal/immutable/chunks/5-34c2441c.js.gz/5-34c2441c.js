import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-17407eec.js";export{t as component};
