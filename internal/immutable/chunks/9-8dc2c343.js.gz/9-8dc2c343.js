import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-1479133c.js";export{t as component};
