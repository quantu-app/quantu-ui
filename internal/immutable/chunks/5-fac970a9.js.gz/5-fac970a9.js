import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-fcd3c09b.js";export{t as component};
