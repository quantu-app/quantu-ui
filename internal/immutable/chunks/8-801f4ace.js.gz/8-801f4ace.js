import{default as t}from"../components/pages/(authed)/quizzes/_local_quiz_id_/questions/create/_page.svelte-a353092b.js";export{t as component};
