import{default as t}from"../components/pages/(authed)/quizzes/_local_learnable_resource_/_page.svelte-593598a6.js";export{t as component};
