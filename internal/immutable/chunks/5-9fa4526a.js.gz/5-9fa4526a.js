import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-ca481f4f.js";export{t as component};
