import{_ as r}from"./_layout-c95dd0ea.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-270ded90.js";export{t as component,r as universal};
