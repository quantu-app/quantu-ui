import{default as t}from"../components/pages/(unauthed)/login/_page.svelte-ab82be7f.js";export{t as component};
