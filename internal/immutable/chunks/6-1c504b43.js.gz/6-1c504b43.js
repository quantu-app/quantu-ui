import{default as t}from"../components/pages/(authed)/quizzes/_local_learnable_resource_/_page.svelte-e7df6eaa.js";export{t as component};
