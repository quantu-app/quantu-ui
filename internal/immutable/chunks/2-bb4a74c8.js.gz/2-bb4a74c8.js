import{_ as r}from"./_layout-e553e62f.js";import{default as t}from"../components/pages/(authed)/_layout.svelte-488abf67.js";export{t as component,r as universal};
