import{default as t}from"../components/pages/(authed)/quizzes/_local_learnable_resource_/_page.svelte-54cf53ed.js";export{t as component};
