import{default as t}from"../entry/(authed)-quizzes-_local_learnable_resource_-page.svelte.c26445f4.js";export{t as component};
