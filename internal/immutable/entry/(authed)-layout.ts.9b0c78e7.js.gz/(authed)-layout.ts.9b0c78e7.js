import"../chunks/user.27d456be.js";import{l as m,s as p}from"../chunks/_layout.6c231fc0.js";import"../chunks/paths.c0dae15b.js";export{m as load,p as ssr};
