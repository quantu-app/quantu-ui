import"../chunks/user.27d456be.js";import{l as m,s as p}from"../chunks/_layout.b6d4f3d9.js";import"../chunks/paths.345d5cb6.js";export{m as load,p as ssr};
